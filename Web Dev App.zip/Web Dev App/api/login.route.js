import express from "express"
// import LoginCtrl from "./login.controller.js"

//creating of router
const router = express.Router()


router.route("/").get((req, res) => res.send("index.html"))

export default router