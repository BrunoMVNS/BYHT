 import userDAO from "../dao/usersDAO.s"

export default class UserController {
  static async apiPostUsers (req, res next) {
    try {
      const location = req.body.location
      const login = req.body.login
      const user = req.body.user

      
    }
  }
}